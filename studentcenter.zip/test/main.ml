open OUnit2
open Final_project_3110
open Classdb
open Auth
open Userdb
open Server

(*TESTING PLAN:

  In the final running of our test suite, we are calling test cases that were
  constructed for the user inputted csclasses.json, as well as the tests
  constructed for the json from the Fall 2022 Cornell Class Roster json—which we
  pulled using an api. It was necessary to craft test cases for both of these
  json files, as we wanted to be sure that our functions and our parser operated
  correctly regardless of the json.

  (1) Which parts of the system were automatically tested by OUnit vs. manually
  tested:

  The bulk of our testing system was concentrated in testing three categories:
  the search and query functions from the database, testing the ability for
  users to interact with the database and update their schedules, and testing
  the appearance of our Terminal User Interface.

  During the implementation process, we heavily used both the OUnit test suite
  as well as the terminal and manual testing to tailor our program’s response
  and action based on the expectations of the user:

  In the OUnit test suite, our tests covered each of the search functions, which
  searched for classes based on credits, instructors, class code, etc. We also
  tested the user interaction with the databse by viewing a user's schedule, and
  testing the impact of them adding and dropping coruses from the database.
  Combined, these tests not only ensured that users' would be able to query
  efficiently, but also confirmed that user information would update based on
  these changes made in the terminal.

  In terms of manual testing, the biggest use-case was for our Terminal User
  Interface, where we used manual testing to ensure that the interface was up to
  our aesthetic standards—and offered a comprehensive user experience.

  (2) What modules were tested and how test cases were developed:

  Throughout the assignment, we used a combination of glass-box and black-box
  testing as we tested modules Parse, ClassDB, and UserDB. While often we were
  able to craft test cases off the specifications alone, there were instances
  where we referenced the implementation in order to ensure that all cases had
  covered in the OUnit suite. These test cases were carefully created to ensure
  full coverage and correctness by verifying the expected outputs using the
  corresponding json file.

  (3) Argument for why our testing demonstrates correctness of the program:

  Our testing file effectively demonstrates the correctness of our program for a
  number of reasons. First and foremost, it cohesively and accurately tests each
  of the necessary user functions. For our group, the most important aspect was
  ensuring that the user experience was flawless and users were able to use all
  of the program's functionality to the fullest extend. Beyond that, our testing
  program efficiently covers all the edge cases you might encounter, which is an
  important element of testing for correctness. Through out testing process, we
  were able to number of hidden bugs, but were able to resolve these bugs and
  re-test. Lastly, we can note that the manual testing of our program helped
  ensure correctness because it allowed us to see in real time how our program
  was responding to the interactions of the user. This helped us confirm or deny
  right away if our impleemntation was correct—even beyond just seeing that our
  test cases passed.*)

(** [cmp_set_like_lists lst1 lst2] compares two lists to see whether they are
    equivalent set-like lists. That means checking two things. First, they must
    both be "set-like", meaning that they do not contain any duplicates. Second,
    they must contain the same elements, though not necessarily in the same
    order. *)
let cmp_set_like_lists lst1 lst2 =
  let uniq1 = List.sort_uniq compare lst1 in
  let uniq2 = List.sort_uniq compare lst2 in
  List.length lst1 = List.length uniq1
  && List.length lst2 = List.length uniq2
  && uniq1 = uniq2

(** [pp_string s] pretty-prints string [s]. *)
let pp_string s = "\"" ^ s ^ "\""

(** [pp_list pp_elt lst] pretty-prints list [lst], using [pp_elt] to
    pretty-print each element of [lst]. *)
let pp_list pp_elt lst =
  let pp_elts lst =
    let rec loop n acc = function
      | [] -> acc
      | [ h ] -> acc ^ pp_elt h
      | h1 :: (h2 :: t as t') ->
          if n = 100 then acc ^ "..." (* stop printing long list *)
          else loop (n + 1) (acc ^ pp_elt h1 ^ "; ") t'
    in
    loop 0 "" lst
  in
  "[" ^ pp_elts lst ^ "]"

(** [test name f exp] constructs an OUnit test that asserts the equality between
    [exp] and [f].*)
let test name f exp = name >:: fun _ -> assert_equal exp f

(** [set_like_lst_test name lst1 lst2] constructs an OUnit test that asserts the
    equality between set-like string lists [lst1] and [lst2].*)
let set_like_lst_test name lst1 lst2 =
  name >:: fun _ ->
  assert_equal ~cmp:cmp_set_like_lists ~printer:(pp_list pp_string) lst1 lst2

let data_dir_prefix = "data" ^ Filename.dir_sep
let csclasses = Yojson.Basic.from_file (data_dir_prefix ^ "cs-classes.json")
let users = Yojson.Basic.from_file (data_dir_prefix ^ "user_test.json")

let api_data_FA22 =
  Server.json_from_uri
    "https://classes.cornell.edu/api/2.0/search/classes.json?roster=FA22&subject=CS"

let classes_in_cornell_roster_fa22 = Classdb.from_json_api api_data_FA22
let fa22_clst = view_all_class classes_in_cornell_roster_fa22

let api_data_SP22 =
  Server.json_from_uri
    "https://classes.cornell.edu/api/2.0/search/classes.json?roster=SP22&subject=CS"

let classes_in_cornell_roster_sp22 = Classdb.from_json_api api_data_SP22
let sp22_clst = view_all_class classes_in_cornell_roster_sp22
let class_in_t = Classdb.from_json csclasses
let user_in_t = Userdb.from_json users
let clst = view_all_class class_in_t

let tst_user1 =
  get_user "ocr5"
    "07610ccf186d55fef0165adc3d30b14ce03ab6f69b110206031196d7ced8a250" user_in_t

let tst_user2 =
  get_user "asu7"
    "2e4c06978057990760f3e5b473dcbfe88dad321764b2636cb9dab4382ae70bc9" user_in_t

let tst_user3 =
  get_user "bdm84"
    "1ee3beeafc258e92e1faefc442d333a15e005a81c844bc5368a472ec019b4e2c" user_in_t

let tst_user4 =
  get_user "wph52"
    "ad18a02a5842d1ddb88e5b24adf966ec65ac2d669ab63ebf42971c0125d5acde" user_in_t

let added_class_tst = add_class tst_user1 9519 user_in_t class_in_t
let drop_class_tst = drop_class tst_user1 9099 user_in_t class_in_t
let drop_class_tst2 = drop_class tst_user4 9099 user_in_t class_in_t

let tst_user1_added_class =
  get_user "ocr5"
    "07610ccf186d55fef0165adc3d30b14ce03ab6f69b110206031196d7ced8a250"
    (fst added_class_tst)

let tst_user4_added_class =
  get_user "wph52"
    "ad18a02a5842d1ddb88e5b24adf966ec65ac2d669ab63ebf42971c0125d5acde"
    (fst added_class_tst)

let tst_user1_dropped_class =
  get_user "ocr5"
    "07610ccf186d55fef0165adc3d30b14ce03ab6f69b110206031196d7ced8a250"
    (fst drop_class_tst)

let tst_user4_dropped_class =
  get_user "wph52"
    "ad18a02a5842d1ddb88e5b24adf966ec65ac2d669ab63ebf42971c0125d5acde"
    (fst drop_class_tst2)

(** [code_list clst] is the set-like list of class codes of clst. For example,
    (refer to cs-classes.json) if [clst] is a list of "Functional Programming",
    "OOP", and "Intro to Computing using Python", the expected result is
    [\["42533"; "43153"; "9222"\]]*)
let code_list clst =
  let rec code_list_helper = function
    | [] -> []
    | h :: t -> string_of_int (get_class_code h) :: code_list_helper t
  in
  List.sort_uniq String.compare (code_list_helper clst)

let code_list_int clst =
  let rec code_list_helper = function
    | [] -> []
    | h :: t -> string_of_int h :: code_list_helper t
  in
  List.sort_uniq String.compare (code_list_helper clst)

(** Test cases for Classdb compilation unit*)
let classdb_test_one =
  [
    set_like_lst_test "searching for 3 credit classes in cs-classes.json"
      (code_list (search_credits 3 clst))
      [ "43153" ];
    set_like_lst_test "searching for 4 credit classes in cs-classes.json"
      (code_list (search_credits 4 clst))
      [ "9222"; "42533" ];
    set_like_lst_test
      "searching for credit number that does not exist in cs-classes.json"
      (code_list (search_credits 5 clst))
      [];
    set_like_lst_test "searching for negative credit number in cs-classes.json"
      (code_list (search_credits (-2) clst))
      [];
    set_like_lst_test
      "searching for classes with [Programming] in their name in \
       cs-classes.json"
      (code_list (search_name [ "Programming" ] clst))
      [ "42533"; "43153" ];
    set_like_lst_test
      "searching for classes with [Computing; Programming] in their name in \
       cs-classes.json"
      (code_list (search_name [ "Computing"; "Programming" ] clst))
      [ "9222"; "42533"; "43153" ];
    set_like_lst_test
      "searching for a class name that does not exist in cs-classes.json"
      (code_list (search_name [ "Go"; "Big"; "Red" ] clst))
      [];
    set_like_lst_test
      "One of the elements in the string list is not contained by any class's \
       name while another element is contained by classes in cs-classes.json"
      (code_list (search_name [ ";"; "Functional" ] clst))
      [ "42533" ];
    set_like_lst_test "Queries with a typo [Functionan]"
      (code_list (search_name [ "Functionan" ] clst))
      [];
    set_like_lst_test "Queries with a typo [Obje]" []
      (code_list (search_name [ "Obje" ] clst));
    set_like_lst_test "searching for classes with code 9222"
      (code_list (search_code 9222 clst))
      [ "9222" ];
    set_like_lst_test
      "searching for classes with code 1000 (which does not exist)"
      (code_list (search_code 1000 clst))
      [];
    set_like_lst_test "searching for CS 1110"
      (code_list (search_dept_id "CS" 1110 clst))
      [ "9222" ];
    set_like_lst_test "searching for CS 3110"
      (code_list (search_dept_id "CS" 3110 clst))
      [ "42533" ];
    set_like_lst_test "searching for MATH 1110 (dept doesn't exist)"
      (code_list (search_dept_id "MATH" 1110 clst))
      [];
    set_like_lst_test "searching for CS 2112 (doesn't exist)"
      (code_list (search_dept_id "CS" 2112 clst))
      [];
    set_like_lst_test
      "searching for BIOMG 1350 (both dept and number doesn't exist)"
      (code_list (search_dept_id "BIOMG" 1350 clst))
      [];
    set_like_lst_test
      "searching for BIOMG 1350 (both dept and number doesn't exist)"
      (code_list (search_dept_id "BIOMG" 1350 clst))
      [];
    set_like_lst_test "searching for Clarkson's class"
      (code_list (search_instructor "Clarkson" clst))
      [ "42533" ];
    set_like_lst_test "searching for White's class"
      (code_list (search_instructor "White" clst))
      [ "9222" ];
    set_like_lst_test "searching for non-existing instructor's class"
      (code_list (search_instructor "Walth" clst))
      []
    (* test "exponent test" (Auth.exponent 2 8) 256; *);
  ]

(* These test cases test upon our new user-inputted json file of all the cs
   classes from*)
let classdb_test_two =
  [
    set_like_lst_test
      "searching for 3 credit classes in updated cs-classes.json"
      (code_list (search_credits 3 clst))
      [
        "10048";
        "10378";
        "18030";
        "9090";
        "9098";
        "9105";
        "9259";
        "9295";
        "9308";
        "9754";
      ];
    set_like_lst_test
      "searching for 2 credit classes in updated cs-classes.json, which \
       doesn't exist"
      (code_list (search_credits 2 clst))
      [];
    set_like_lst_test
      "searching for -100 credit classes in updated cs-classes.json, which \
       doesn't exist"
      (code_list (search_credits (-100) clst))
      [];
    set_like_lst_test
      "searching for 4 credit classes in updated cs-classes.json"
      (code_list (search_credits 4 clst))
      [
        "18031";
        "18818";
        "20252";
        "9099";
        "9142";
        "9214";
        "9222";
        "9223";
        "9400";
        "9519";
        "9550";
        "9557";
        "9632";
        "9670";
        "9755";
      ];
    set_like_lst_test
      "searching for classes with [Computing] in their name in updated \
       cs-classes.json"
      (code_list (search_name [ "Computing" ] clst))
      [ "9214"; "9222"; "9223" ];
    set_like_lst_test
      "searching for classes with [Introduction] in their name in updated \
       cs-classes.json"
      (code_list (search_name [ "Introduction" ] clst))
      [ "18030"; "9214"; "9222"; "9223"; "9259"; "9670"; "9754"; "9755" ];
    set_like_lst_test
      "searching for classes with [Computing; Programming] in their name in \
       the updated cs-classes.json"
      (code_list (search_name [ "Computing"; "Programming" ] clst))
      [ "9090"; "9099"; "9214"; "9222"; "9223"; "9308"; "9519"; "9550" ];
    set_like_lst_test
      "searching for a class name that does not exist in cs-classes.json"
      (code_list (search_name [ "Not"; "Real"; "Class" ] clst))
      [];
    set_like_lst_test "Queries with a typo [Functionaaaaa]"
      (code_list (search_name [ "Functionanaaaaa" ] clst))
      [];
    set_like_lst_test "Queries with a typo [Objep]"
      (code_list (search_name [ "Objep" ] clst))
      [];
    set_like_lst_test "searching for classes with code 9222 that does exist"
      (code_list (search_code 9222 clst))
      [ "9222" ];
    set_like_lst_test "searching for classes with code 9099 that does exist"
      (code_list (search_code 9099 clst))
      [ "9099" ];
    set_like_lst_test "searching for classes with code 9090 that does exist"
      (code_list (search_code 9090 clst))
      [ "9090" ];
    set_like_lst_test "searching for classes with code 10378 that does exist"
      (code_list (search_code 10378 clst))
      [ "10378" ];
    set_like_lst_test "searching for classes with code 1909 that doesn't exist"
      (code_list (search_code 1909 clst))
      [];
    set_like_lst_test "searching for classes with code 9214"
      (code_list (search_code 9214 clst))
      [ "9214" ];
    set_like_lst_test "searching for classes with code 9223"
      (code_list (search_code 9223 clst))
      [ "9223" ];
    set_like_lst_test "searching for Clarkson's class"
      (code_list (search_instructor "Clarkson" clst))
      [ "9099" ];
    set_like_lst_test "searching for White's class"
      (code_list (search_instructor "White" clst))
      [ "9222"; "9223" ];
    set_like_lst_test "searching for Gries' class"
      (code_list (search_instructor "Gries" clst))
      [];
    set_like_lst_test "searching for Foster's class"
      (code_list (search_instructor "Foster" clst))
      [ "9519" ];
    set_like_lst_test "searching for non-existing instructor's class"
      (code_list (search_instructor "Walth" clst))
      [];
    set_like_lst_test "searching for CS 2110"
      (code_list (search_dept_id "CS" 2110 clst))
      [ "9090" ];
    set_like_lst_test "searching for CS 4820"
      (code_list (search_dept_id "CS" 4820 clst))
      [ "9670" ];
    set_like_lst_test "searching for PSYCH 1110 (deptartment doesn't exist)"
      (code_list (search_dept_id "PSYCH" 1110 clst))
      [];
    set_like_lst_test "viewing Owen's schedule from csclasses.json"
      (code_list_int (view_schedule_list tst_user1 class_in_t))
      [ "10378"; "9099"; "9632"; "9754" ];
    set_like_lst_test "viewing Akshay's schedule from csclasses.json"
      (code_list_int (view_schedule_list tst_user2 class_in_t))
      [ "9090"; "9098"; "9099"; "9519" ];
    set_like_lst_test "viewing Ben's schedule from csclasses.json"
      (code_list_int (view_schedule_list tst_user3 class_in_t))
      [ "18030"; "18818"; "9099"; "9142" ];
    set_like_lst_test "viewing Will's schedule from csclasses.json"
      (code_list_int (view_schedule_list tst_user4 class_in_t))
      [
        "10048";
        "10378";
        "18030";
        "18031";
        "18818";
        "20252";
        "9090";
        "9098";
        "9099";
        "9105";
        "9142";
        "9214";
        "9222";
        "9223";
        "9259";
        "9308";
        "9400";
        "9519";
        "9550";
        "9557";
        "9632";
        "9670";
        "9754";
        "9755";
      ];
    set_like_lst_test "testing Owen's schedule with an added class"
      (code_list_int (view_schedule_list tst_user1_added_class class_in_t))
      [ "10378"; "9099"; "9519"; "9632"; "9754" ];
    set_like_lst_test
      "testing Will's schedule after adding a class he was already enrolled in"
      (code_list_int (view_schedule_list tst_user4_added_class class_in_t))
      [
        "10048";
        "10378";
        "18030";
        "18031";
        "18818";
        "20252";
        "9090";
        "9098";
        "9099";
        "9105";
        "9142";
        "9214";
        "9222";
        "9223";
        "9259";
        "9308";
        "9400";
        "9519";
        "9550";
        "9557";
        "9632";
        "9670";
        "9754";
        "9755";
      ];
    set_like_lst_test
      "testing Will's schedule after dropping a class he was enrolled in"
      (code_list_int (view_schedule_list tst_user4_dropped_class class_in_t))
      [
        "10048";
        "10378";
        "18030";
        "18031";
        "18818";
        "20252";
        "9090";
        "9098";
        "9105";
        "9142";
        "9214";
        "9222";
        "9223";
        "9259";
        "9308";
        "9400";
        "9519";
        "9550";
        "9557";
        "9632";
        "9670";
        "9754";
        "9755";
      ];
  ]

(* These test cases test upon our newly implemented api integrated json file of
   all the cs classes from a particular semester, in this case—fall 2022*)
let classdb_test_three =
  [
    set_like_lst_test
      "viewing Owen's schedule using the cornell class roster api for Fall 2022"
      (code_list_int
         (view_schedule_list tst_user1 classes_in_cornell_roster_fa22))
      [ "10378"; "9099"; "9632"; "9754" ];
    set_like_lst_test
      "viewing Akshay's schedule using the cornell class roster api for Fall \
       2022"
      (code_list_int
         (view_schedule_list tst_user2 classes_in_cornell_roster_fa22))
      [ "9090"; "9098"; "9099"; "9519" ];
    set_like_lst_test
      "viewing Ben's schedule using the cornell class roster api for Fall 2022"
      (code_list_int
         (view_schedule_list tst_user3 classes_in_cornell_roster_fa22))
      [ "18030"; "18818"; "9099"; "9142" ];
    set_like_lst_test
      "viewing Will's schedule using the cornell class roster api for Fall 2022"
      (code_list_int
         (view_schedule_list tst_user4 classes_in_cornell_roster_fa22))
      [
        "10048";
        "10378";
        "18030";
        "18031";
        "18818";
        "20252";
        "9090";
        "9098";
        "9099";
        "9105";
        "9142";
        "9214";
        "9222";
        "9223";
        "9259";
        "9308";
        "9400";
        "9519";
        "9550";
        "9557";
        "9632";
        "9670";
        "9754";
        "9755";
      ];
    set_like_lst_test
      "testing Owen's schedule with an added class  from the Cornell class \
       roster api fall 2022 json"
      (code_list_int
         (view_schedule_list tst_user1_added_class
            classes_in_cornell_roster_fa22))
      [ "10378"; "9099"; "9519"; "9632"; "9754" ];
    set_like_lst_test
      "testing Will's schedule after adding a class he was already enrolled \
       in  from the Cornell class roster api fall 2022 json"
      (code_list_int
         (view_schedule_list tst_user4_added_class
            classes_in_cornell_roster_fa22))
      [
        "10048";
        "10378";
        "18030";
        "18031";
        "18818";
        "20252";
        "9090";
        "9098";
        "9099";
        "9105";
        "9142";
        "9214";
        "9222";
        "9223";
        "9259";
        "9308";
        "9400";
        "9519";
        "9550";
        "9557";
        "9632";
        "9670";
        "9754";
        "9755";
      ];
    set_like_lst_test
      "testing Will's schedule after dropping a class he was enrolled from the \
       Cornell class roster api fall 2022 json"
      (code_list_int
         (view_schedule_list tst_user4_dropped_class
            classes_in_cornell_roster_fa22))
      [
        "10048";
        "10378";
        "18030";
        "18031";
        "18818";
        "20252";
        "9090";
        "9098";
        "9105";
        "9142";
        "9214";
        "9222";
        "9223";
        "9259";
        "9308";
        "9400";
        "9519";
        "9550";
        "9557";
        "9632";
        "9670";
        "9754";
        "9755";
      ];
    set_like_lst_test
      "searching for 3 credit classes using the cornell class roster api for \
       Fall 2022"
      (code_list (search_credits 3 fa22_clst))
      [
        "10013";
        "10048";
        "10093";
        "10155";
        "10157";
        "10378";
        "17892";
        "18030";
        "18381";
        "18419";
        "18421";
        "19135";
        "9090";
        "9098";
        "9105";
        "9259";
        "9295";
        "9315";
        "9360";
        "9637";
        "9694";
        "9733";
        "9754";
        "9758";
        "9788";
        "9790";
        "9796";
      ];
    set_like_lst_test
      "searching for 2 credit classes using the cornell class roster api for \
       Fall 2022"
      (code_list (search_credits 2 fa22_clst))
      [
        "10156";
        "10158";
        "11594";
        "17920";
        "9109";
        "9296";
        "9753";
        "9794";
        "9795";
      ];
    set_like_lst_test
      "searching for -100 credit classes using the cornell class roster api \
       for Fall 2022t"
      (code_list (search_credits (-100) fa22_clst))
      [];
    set_like_lst_test
      "searching for 4 credit classes using the cornell class roster api for \
       Fall 2022"
      (code_list (search_credits 4 fa22_clst))
      [
        "10011";
        "10089";
        "10159";
        "17882";
        "17883";
        "17884";
        "17893";
        "17935";
        "18031";
        "18033";
        "18035";
        "18818";
        "19106";
        "19134";
        "19808";
        "20252";
        "9099";
        "9130";
        "9142";
        "9214";
        "9222";
        "9337";
        "9394";
        "9400";
        "9519";
        "9550";
        "9557";
        "9564";
        "9632";
        "9670";
        "9671";
        "9717";
        "9755";
        "9757";
        "9760";
        "9793";
      ];
    set_like_lst_test
      "searching for classes with [Computing] in their name using the cornell \
       class roster api for Fall 2022"
      (code_list (search_name [ "Computing" ] fa22_clst))
      [ "18033"; "9214"; "9222"; "9351" ];
    set_like_lst_test
      "searching for classes with [Computing; Programming] using the cornell \
       class roster api for Fall 2022"
      (code_list (search_name [ "Computing"; "Programming" ] fa22_clst))
      [ "18033"; "9214"; "9222"; "9351"; "9753" ];
    set_like_lst_test
      "searching for a class name that does not exist in using the cornell \
       class roster api for Fall 2022"
      (code_list (search_name [ "Not"; "Real"; "Class" ] fa22_clst))
      [];
    set_like_lst_test
      "Queries with a typo [Functionaaaaa] using the cornell class roster api \
       for Fall 2022"
      (code_list (search_name [ "Functionanaaaaa" ] fa22_clst))
      [];
    set_like_lst_test
      "Queries with a typo [Objep] using the cornell class roster api for Fall \
       2022"
      (code_list (search_name [ "Objep" ] fa22_clst))
      [];
    set_like_lst_test
      "searching for classes with code 9222 that does exist using the cornell \
       class roster api for Fall 2022"
      (code_list (search_code 9222 fa22_clst))
      [ "9222" ];
    set_like_lst_test
      "searching for classes with code 9099 that does exist using the cornell \
       class roster api for Fall 2022"
      (code_list (search_code 9099 fa22_clst))
      [ "9099" ];
    set_like_lst_test
      "searching for classes with code 9090 that does exist using the cornell \
       class roster api for Fall 2022"
      (code_list (search_code 9090 fa22_clst))
      [ "9090" ];
    set_like_lst_test
      "searching for classes with code 10378 that does exist using the cornell \
       class roster api for Fall 2022"
      (code_list (search_code 10378 fa22_clst))
      [ "10378" ];
    set_like_lst_test
      "searching for classes with code 1909 that doesn't exist using the \
       cornell class roster api for Fall 2022"
      (code_list (search_code 1909 fa22_clst))
      [];
    set_like_lst_test
      "searching for classes with code 9214 using the cornell class roster api \
       for Fall 2022"
      (code_list (search_code 9214 fa22_clst))
      [ "9214" ];
    set_like_lst_test
      "searching for CS 2110  using the cornell class roster api for Fall 2022"
      (code_list (search_dept_id "CS" 2110 fa22_clst))
      [ "9090" ];
    set_like_lst_test
      "searching for CS 4820  using the cornell class roster api for Fall 2022"
      (code_list (search_dept_id "CS" 4820 fa22_clst))
      [ "9670" ];
    set_like_lst_test
      "searching for PSYCH 1110 (department doesn't exist) using the cornell \
       class roster api for Fall 2022"
      (code_list (search_dept_id "PSYCH" 1110 fa22_clst))
      [];
  ]

let data_dir_prefix = "data" ^ Filename.dir_sep

let write_test =
  let db =
    Yojson.Basic.from_file (data_dir_prefix ^ "users.json") |> Userdb.from_json
  in
  [ ("write test " >:: fun _ -> assert_equal (db |> Userdb.to_json) ()) ]

let tests =
  "final project test suite"
  >::: List.flatten [ classdb_test_three @ classdb_test_two @ write_test ]

let _ = run_test_tt_main tests
