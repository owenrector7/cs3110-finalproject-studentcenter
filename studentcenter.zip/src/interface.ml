let help_student () = raise (Failure "To be implemented : help_student")
let help_admin () = raise (Failure "To be implemented : help_admin")
let logout () = raise (Failure "To be implemented : logout")
let quit () = raise (Failure "To be implemented : quit")